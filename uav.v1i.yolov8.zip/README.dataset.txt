# uav > 2023-11-08 5:03pm
https://universe.roboflow.com/uav-cmkao/uav-6oylx

Provided by a Roboflow user
License: CC BY 4.0

